Originals:

* [SPARQL 1.1 Overview](http://www.w3.org/TR/2013/REC-sparql11-overview-20130321)
* [SPARQL 1.1 Query Language](http://www.w3.org/TR/2013/REC-sparql11-query-20130321)
* [SPARQL 1.1 Update](http://www.w3.org/TR/2013/REC-sparql11-update-20130321)
* [SPARQL1.1 Service Description](http://www.w3.org/TR/2013/REC-sparql11-service-description-20130321)
* [SPARQL 1.1 Federated Query](http://www.w3.org/TR/2013/REC-sparql11-federated-query-20130321)
* [SPARQL 1.1 Query Results JSON Format](http://www.w3.org/TR/2013/REC-sparql11-results-json-20130321)
* [SPARQL 1.1 Query Results CSV and TSV Formats](http://www.w3.org/TR/2013/REC-sparql11-results-csv-tsv-20130321)
* [SPARQL Query Results XML Format (Second Edition)](http://www.w3.org/TR/2013/REC-rdf-sparql-XMLres-20130321)
* [SPARQL 1.1 Entailment Regimes](http://www.w3.org/TR/2013/REC-sparql11-entailment-20130321)
* [SPARQL 1.1 Protocol](http://www.w3.org/TR/2013/REC-sparql11-protocol-20130321)
* [SPARQL 1.1 Graph Store HTTP Protocol](http://www.w3.org/TR/2013/REC-sparql11-http-rdf-update-20130321)

Processed with:

```shell
function tidyhtml() {
    local F="$1"
    local B="$(basename "$F" .html)"
    tidy -i -q -utf8 -ashtml -w 200 < "$F" > "${B}".tidy.html
}

tidyhtml 'SPARQL 1.1 Entailment Regimes.html'
tidyhtml 'SPARQL 1.1 Federated Query.html'
tidyhtml 'SPARQL 1.1 Graph Store HTTP Protocol.html'
tidyhtml 'SPARQL 1.1 Overview.html'
tidyhtml 'SPARQL 1.1 Protocol.html'
tidyhtml 'SPARQL 1.1 Query Language.html'
tidyhtml 'SPARQL 1.1 Query Results CSV and TSV Formats.html'
tidyhtml 'SPARQL 1.1 Query Results JSON Format.html'
tidyhtml 'SPARQL 1.1 Service Description.html'
tidyhtml 'SPARQL 1.1 Update.html'
tidyhtml 'SPARQL Query Results XML Format (Second Edition).html'
```
